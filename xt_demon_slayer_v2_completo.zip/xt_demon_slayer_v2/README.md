# XTREINO DEMꓳN SLꓥYER — versão 2

Site Node.js + SQLite, 12 vagas, inscrições com logo e todos os jogadores, WhatsApp do capitão privado no ADM, reservas, aprovação, slots públicos, ranking com pontuação inserida manualmente pelo ADM, edição de regras e botão FINALIZAR XT que exclui todas as inscrições e zera o ranking.

## Instalar
1. Instale Node.js 20 ou 22.
2. Extraia o ZIP e abra o terminal na pasta.
3. Execute `npm install`.
4. Copie `.env.example` para `.env`, configure `ADMIN_USER=killerX`, uma senha **nova e forte** em `ADMIN_PASSWORD` e um segredo aleatório de pelo menos 32 caracteres em `SESSION_SECRET`. Não use a senha compartilhada no chat.
5. Execute `npm start` e abra `http://localhost:3000`.

## Publicar
Use um servidor Node.js com HTTPS, disco persistente para `data/` e `uploads/`, backups e variáveis de ambiente. Não envie `.env` ao GitHub. O armazenamento de sessão padrão em memória deve ser substituído por um store persistente antes de produção. Não hospede em serviço sem disco persistente, pois as inscrições e logos seriam perdidas.

## Uso
As inscrições pendentes e aprovadas ocupam as 12 vagas. Apenas aprovadas aparecem nos slots e ranking. O ADM pode inserir manualmente pontos de colocação, abates e total. Não há cálculo automático de LBFF 2021. Finalizar XT exige digitar `FINALIZAR XT` e confirmar. Esta operação é irreversível e apaga todos os dados das equipes, inclusive logos e ranking.
